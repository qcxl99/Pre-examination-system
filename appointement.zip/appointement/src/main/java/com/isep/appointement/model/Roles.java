package com.isep.appointement.model;

public enum Roles {

    Patient,

    Doctor,

    ADMIN;


}
