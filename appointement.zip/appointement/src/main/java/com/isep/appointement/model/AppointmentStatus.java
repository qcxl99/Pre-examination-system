package com.isep.appointement.model;


public enum AppointmentStatus {
    pending,
    enabled,
    canceled,
}
