package com.isep.appointement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointementApplicationTests {

    @Test
    void contextLoads() {
    }

}
